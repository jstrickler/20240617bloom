from samplelib import *  # import all functions (that do not start with _) from samplelib module into current namespace

spam()  # module name not needed to call function spam()
ham()
