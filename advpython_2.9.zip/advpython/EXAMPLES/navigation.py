
current_types = 'slow medium fast'.split()

def current():
    return current_types[0]
