import samplelib  # import samplelib module (samplelib.py) -- creates object named samplelib of type "Module"

samplelib.spam()  # call function spam() in module samplelib
samplelib.ham()
