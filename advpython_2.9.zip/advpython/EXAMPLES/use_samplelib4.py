from samplelib import spam as pig, ham as hog  # import functions spam and ham, aliased to pig and hog

pig()
hog()
