from samplelib import spam, ham  # import functions spam and ham from samplelib module into current namespace -- does not create the module object

spam()  # module name not needed to call function spam()
ham()
