import electrical as e  # import module electrical
import navigation as n  # import module navigation

print(e.current())  # use the current() function in electrical
print(n.current())  # use the current() function in navigation
